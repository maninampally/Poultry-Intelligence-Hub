'use client'

import { useState } from 'react'
import {
  AlertTriangle,
  ArrowDownToLine,
  ArrowUpRight,
  Bell,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleHelp,
  ClipboardCheck,
  CloudOff,
  Droplets,
  Egg,
  Factory,
  Feather,
  LayoutDashboard,
  Menu,
  WalletCards,
  MoreHorizontal,
  PackageOpen,
  RefreshCw,
  Scale,
  Settings2,
  ShieldCheck,
  Sprout,
  Truck,
  Users,
  Utensils,
  Wifi,
  X,
  Zap,
} from 'lucide-react'

const navItems = [
  { label: 'Today', icon: LayoutDashboard },
  { label: 'Daily round', icon: ClipboardCheck },
  { label: 'Batches', icon: Egg },
  { label: 'Tasks', icon: CheckCircle2 },
  { label: 'Finance', icon: WalletCards },
]

const actions = [
  { title: 'Waterline pressure low in Shed B', detail: 'Check pressure regulator before next round', tone: 'urgent', icon: Droplets },
  { title: "Record today’s feed use", detail: 'Daily round is waiting for one record', tone: 'due', icon: Utensils },
  { title: 'Weigh sample birds', detail: 'Due tomorrow · 30 bird sample', tone: 'attention', icon: Scale },
]

const tasks = [
  { title: 'Inspect waterline pressure', assignee: 'Ramesh K.', time: 'Due now', status: 'Urgent' },
  { title: 'Record feed issue · Shed B', assignee: 'You', time: 'Today, 5:00 PM', status: 'Due' },
  { title: 'Clean tank and flush lines', assignee: 'Suresh P.', time: 'Tomorrow, 8:00 AM', status: 'Scheduled' },
]

const activity = [
  { text: 'Daily round started', by: 'You', time: '8 min ago', icon: ClipboardCheck },
  { text: '12 mortality recorded', by: 'Ramesh K.', time: '1 hr ago', icon: Feather },
  { text: 'Feed received · 500 kg', by: 'You', time: 'Yesterday', icon: PackageOpen },
]

const trendData = [
  { day: 'Tue', water: 72, feed: 58 },
  { day: 'Wed', water: 77, feed: 68 },
  { day: 'Thu', water: 83, feed: 74 },
  { day: 'Fri', water: 79, feed: 70 },
  { day: 'Sat', water: 88, feed: 82 },
  { day: 'Sun', water: 75, feed: 78 },
  { day: 'Mon', water: 67, feed: 84 },
]

function LogoMark() {
  return <span className="logo-mark" aria-hidden="true"><Sprout size={21} strokeWidth={2.2} /><i /><i /></span>
}

function IconBadge({ icon: Icon, className = '' }: { icon: typeof Droplets; className?: string }) {
  return <span className={`icon-badge ${className}`} aria-hidden="true"><Icon size={17} strokeWidth={2.1} /></span>
}

function MetricCard({ label, value, unit, note, icon: Icon, tone = 'teal' }: { label: string; value: string; unit?: string; note: string; icon: typeof Droplets; tone?: string }) {
  return (
    <article className={`metric-card metric-${tone}`}>
      <div className="metric-top"><span>{label}</span><IconBadge icon={Icon} className="metric-icon" /></div>
      <div className="metric-value">{value} <small>{unit}</small></div>
      <div className="metric-note">{note}</div>
    </article>
  )
}

function TrendChart() {
  return <article className="trend-card">
    <div className="trend-header"><div><span className="eyebrow teal-text">7-DAY TREND</span><h2>Water & feed usage</h2><p>Relative usage against the flock plan</p></div><div className="trend-legend"><span><i className="water-dot" /> Water</span><span><i className="feed-dot" /> Feed</span></div></div>
    <div className="trend-chart" aria-label="Seven day water and feed usage trend">
      <div className="chart-scale"><span>100%</span><span>50%</span><span>0%</span></div>
      <div className="chart-plot"><div className="chart-grid"><i /><i /><i /></div><div className="chart-bars">{trendData.map((point) => <div className="chart-day" key={point.day}><div className="bar-pair"><span className="bar water-bar" style={{ height: `${point.water}%` }} /><span className="bar feed-bar" style={{ height: `${point.feed}%` }} /></div><small>{point.day}</small></div>)}</div></div>
    </div>
    <div className="trend-footer"><span><b>Today</b> water is below average</span><strong><ArrowDownToLine size={14} /> 8%</strong></div>
  </article>
}

function FinanceSection() {
  return <section className="page-section finance-page">
    <div className="page-heading"><div><span className="eyebrow teal-text">FINANCIAL PULSE</span><h1>Farm finance</h1><p>Know what this batch is costing and where margin is moving.</p></div><button type="button" className="outline-button"><ArrowDownToLine size={15} /> Export report</button></div>
    <div className="finance-hero"><div><span className="eyebrow">PROJECTED BATCH MARGIN</span><strong>₹4.82L</strong><small>+8.6% vs previous batch</small></div><div className="finance-hero-chart" aria-label="Projected margin rising over six weeks"><span style={{ height: '34%' }} /><span style={{ height: '43%' }} /><span style={{ height: '39%' }} /><span style={{ height: '58%' }} /><span style={{ height: '67%' }} /><span style={{ height: '82%' }} /></div><div className="finance-hero-meta"><span>Revenue forecast</span><b>₹12.4L</b><span>Cost to date</span><b>₹7.58L</b></div></div>
    <div className="metrics-grid finance-metrics"><MetricCard label="Cost per bird" value="₹80.55" note="−₹2.10 vs last batch" icon={Scale} tone="teal" /><MetricCard label="Feed spend" value="₹4.86L" note="64% of total cost" icon={Utensils} tone="amber" /><MetricCard label="Bird value" value="₹9.1L" note="Based on 9,410 live birds" icon={Egg} tone="blue" /><MetricCard label="Cash due soon" value="₹1.24L" note="3 supplier invoices" icon={CalendarDays} tone="purple" /></div>
    <div className="finance-grid"><article className="finance-card"><div className="section-heading"><div><h2>Cost breakdown</h2><span>Batch 24-07 · Day 18</span></div><button className="text-button" type="button">View ledger <ArrowUpRight size={14} /></button></div><div className="cost-row"><span className="cost-label"><i className="cost-feed" /> Feed</span><b>₹4.86L</b><div className="cost-track"><i style={{ width: '64%' }} /></div><small>64%</small></div><div className="cost-row"><span className="cost-label"><i className="cost-chicks" /> Chicks</span><b>₹1.56L</b><div className="cost-track"><i style={{ width: '21%' }} /></div><small>21%</small></div><div className="cost-row"><span className="cost-label"><i className="cost-health" /> Health & vaccines</span><b>₹62K</b><div className="cost-track"><i style={{ width: '8%' }} /></div><small>8%</small></div><div className="cost-row"><span className="cost-label"><i className="cost-ops" /> Labour & operations</span><b>₹54K</b><div className="cost-track"><i style={{ width: '7%' }} /></div><small>7%</small></div></article><article className="finance-card cash-card"><div className="section-heading"><div><h2>Cash flow outlook</h2><span>Next 30 days</span></div><span className="cash-status"><i /> Healthy</span></div><div className="cash-summary"><div><span>Expected inflow</span><strong>₹5.1L</strong></div><div><span>Committed outflow</span><strong>₹1.24L</strong></div></div><div className="cash-list"><div><span><i className="inflow-dot" /> Batch sale · 06 Nov</span><b>+₹5.1L</b></div><div><span><i className="outflow-dot" /> Feed supplier · 18 Oct</span><b>−₹86K</b></div><div><span><i className="outflow-dot" /> Vaccine order · 22 Oct</span><b>−₹38K</b></div></div><button type="button" className="finance-link">Review payments <ArrowUpRight size={14} /></button></article></div>
    <div className="finance-note"><ShieldCheck size={17} /><div><strong>Finance is estimated from recorded operations.</strong><span>Add purchase invoices and sale price to turn projections into confirmed numbers.</span></div><button type="button" className="text-button">Add records <ArrowUpRight size={14} /></button></div>
  </section>
}

function SyncPill({ syncing, onSync }: { syncing: boolean; onSync: () => void }) {
  return <div className={`sync-pill ${syncing ? 'is-syncing' : ''}`} role="status"><span className="sync-dot" /><CloudOff size={14} /> <strong>3 pending records</strong><span className="sr-only"> not yet synced to the server</span><button type="button" aria-label="Sync 3 pending records" onClick={onSync}><RefreshCw size={13} /> {syncing ? 'Syncing…' : 'Sync now'}</button></div>
}

export default function Page() {
  const [active, setActive] = useState('Today')
  const [workerView, setWorkerView] = useState(false)
  const [syncing, setSyncing] = useState(false)
  const [saved, setSaved] = useState(false)
  const [mortality, setMortality] = useState('')
  const [culls, setCulls] = useState('')
  const [feed, setFeed] = useState('')
  const [water, setWater] = useState('')

  const increment = (setter: (value: string) => void, current: string, amount: number) => setter(String(Math.max(0, Number(current || 0) + amount)))
  const syncRecords = () => { setSyncing(true); window.setTimeout(() => setSyncing(false), 900) }

  return (
    <div className={`app-shell ${workerView ? 'worker-view' : ''}`}>
      <aside className="sidebar">
        <div className="brand"><LogoMark /><div><strong>Poultry</strong><span>INTELLIGENCE</span></div></div>
        <div className="farm-switcher"><span className="eyebrow">ACTIVE FARM</span><strong>Green Valley Farms</strong><span className="farm-meta">Karnataka · 3 sheds <ChevronDown size={14} /></span></div>
        <nav className="side-nav" aria-label="Main navigation">
          {navItems.map(({ label, icon: Icon }) => <button key={label} type="button" className={active === label ? 'active' : ''} onClick={() => setActive(label)}><Icon size={18} /><span>{label}</span>{label === 'Tasks' && <b>3</b>}</button>)}
        </nav>
        <div className="sidebar-bottom"><div className="connection"><span className="online-dot" />Online · Last synced just now</div><button type="button" className="profile"><span className="avatar">AK</span><span><strong>Arun Kumar</strong><small>Owner</small></span><MoreHorizontal size={16} /></button></div>
      </aside>

      <main className="main-content">
        <header className="topbar"><button className="mobile-menu" type="button"><Menu size={20} /></button><div className="breadcrumb"><span>Green Valley Farms</span><span>/</span><strong>{active === 'Daily round' ? 'Daily Farm Round' : 'Today'}</strong></div><div className="top-actions"><button className="icon-button" aria-label="Help"><CircleHelp size={18} /></button><button className="icon-button notification" aria-label="Notifications"><Bell size={18} /><i /></button><button className={`settings-button ${workerView ? 'worker-active' : ''}`} type="button" onClick={() => setWorkerView((value) => !value)}><Users size={16} /> {workerView ? 'Worker view' : 'Owner view'}</button></div></header>
        <div className="offline-banner" role="status"><CloudOff size={16} /><span><strong>Offline queue: 3 records pending sync.</strong> Saved locally only; server status remains unconfirmed.</span><button type="button" onClick={syncRecords}><RefreshCw size={14} /> {syncing ? 'Syncing…' : 'Sync now'}</button></div>

        {active === 'Finance' ? <FinanceSection /> : active === 'Daily round' ? (
          <section className="page-section round-page">
            <div className="page-heading"><div><span className="eyebrow teal-text">FIELD RECORD</span><h1>Daily Farm Round</h1><p>Capture the essentials for Shed B in under 90 seconds.</p></div><SyncPill syncing={syncing} onSync={syncRecords} /></div>
            <div className="round-layout"><form className="round-form" onSubmit={(event) => { event.preventDefault(); setSaved(true) }}>
              <div className="form-context"><div><span className="eyebrow">RECORDING FOR</span><strong>Batch 24-07 · Day 18</strong></div><div className="context-shed"><Factory size={17} /> Shed B <ChevronDown size={14} /></div></div>
              <div className="field-grid">
                <label className="field"><span>Date</span><div className="input-wrap"><CalendarDays size={16} /><input type="date" defaultValue="2026-10-12" /></div></label>
                <label className="field"><span>Flock observation</span><select defaultValue="Normal"><option>Normal</option><option>Birds less active</option><option>Uneven distribution</option></select></label>
              </div>
              <div className="section-label"><span>Daily numbers</span><small>Use 0 for a recorded zero. Leave blank if not recorded.</small></div>
              <div className="number-grid">
                {[["Mortality", mortality, setMortality, "birds", 1], ["Culls", culls, setCulls, "birds", 1], ["Feed used", feed, setFeed, "kg", 5], ["Water used", water, setWater, "litres", 10]].map(([label, value, setter, unit, step]) => <label className="number-field" key={label as string}><span>{label as string}</span><div className="number-control"><button type="button" aria-label={`Decrease ${label}`} onClick={() => increment(setter as (v: string) => void, value as string, -(step as number))}>−</button><input inputMode="decimal" aria-label={label as string} placeholder="Not recorded" value={value as string} onChange={(event) => (setter as (v: string) => void)(event.target.value)} /><button type="button" aria-label={`Increase ${label}`} onClick={() => increment(setter as (v: string) => void, value as string, step as number)}>+</button></div><div className="quick-values" aria-label={`${label} quick values`}>{[0, step as number, (step as number) * 2].map((quick) => <button type="button" key={quick} onClick={() => (setter as (v: string) => void)(String(quick))}>{quick}</button>)}</div><small>{unit as string}</small></label>)}
              </div>
              <div className="field-grid"><label className="field"><span>Shed condition</span><select defaultValue="Good"><option>Good</option><option>Needs attention</option><option>Critical issue</option></select></label><label className="field"><span>Health observation <em>Optional</em></span><input placeholder="Add a factual observation" /></label></div>
              <label className="field"><span>Note <em>Optional</em></span><textarea rows={3} placeholder="Anything the next person should know?" /></label>
              <div className="record-status"><ShieldCheck size={18} /><div><strong>Missing data is not treated as zero.</strong><span>You can save a draft and complete this record later.</span></div></div>
              <div className="form-footer"><button type="button" className="secondary-button">Save as draft</button><button type="submit" className="primary-button"><Check size={17} /> Save record</button></div>
              {saved && <div className="saved-banner"><CheckCircle2 size={18} /><div><strong>Saved locally. Waiting to sync.</strong><span>Your record is safely stored on this device.</span></div><button type="button" aria-label="Dismiss" onClick={() => setSaved(false)}><X size={16} /></button></div>}
            </form><aside className="round-aside"><div className="aside-card"><div className="card-heading"><span>ROUND PROGRESS</span><b>2 of 4 required items complete</b></div><div className="progress-track"><div style={{ width: '50%' }} /></div><p>Two items still need attention before this round is complete.</p><div className="check-list"><span><Check size={14} /> Mortality and culls</span><span><Check size={14} /> Feed and water</span><span className="pending"><i /> Flock observation</span><span className="pending"><i /> Shed condition</span></div></div><div className="aside-card light-card"><div className="card-heading"><span>SYNC STATUS</span><Wifi size={15} /></div><strong>Saved locally</strong><p>3 records are waiting for a connection. We’ll sync automatically when you’re back online.</p><button type="button" className="text-button">View sync queue <ArrowUpRight size={14} /></button></div></aside></div>
          </section>
        ) : (
          <section className="page-section">
            <div className="page-heading dashboard-heading"><div><span className="eyebrow teal-text">MONDAY, 12 OCTOBER 2026</span><h1>Good morning, Arun</h1><p>Here’s what needs your attention today.</p></div><SyncPill syncing={syncing} onSync={syncRecords} /></div>
            <div className="batch-banner"><IconBadge icon={Egg} className="batch-orb" /><div className="batch-copy"><span className="eyebrow">ACTIVE BATCH</span><strong>Batch 24-07 <span>·</span> Shed B</strong><small>Day 18 of 42 <i /> Expected harvest 06 Nov 2026</small></div><div className="batch-right"><span>RECORD COMPLETENESS</span><strong>86%</strong><div className="mini-progress"><i /></div></div><button type="button" className="outline-button" onClick={() => setActive('Batches')}>View batch <ArrowUpRight size={15} /></button></div>
            <div className="section-heading"><div><h2>Today at a glance</h2><span>Live records from the current batch</span></div><span className="last-updated"><RefreshCw size={13} /> Updated 8 min ago</span></div>
            <div className="metrics-grid"><MetricCard label="Live birds" value="9,410" note="−12 since yesterday" icon={Feather} tone="teal" /><MetricCard label="Today mortality" value="12" unit="birds" note="0.13% of live flock" icon={AlertTriangle} tone="amber" /><MetricCard label="Feed runway" value="Unknown" note="Not recorded · add recent feed use" icon={Utensils} tone="blue" /><MetricCard label="Daily farm round" value="2 / 4" note="50% complete" icon={ClipboardCheck} tone="purple" /></div>
            <TrendChart />
            <div className="content-grid"><div className="left-column"><div className="section-heading action-heading"><div><h2>Top actions</h2><span>Evidence-backed actions for your farm</span></div><button className="text-button" type="button" onClick={() => setActive('Tasks')}>View all <ArrowUpRight size={14} /></button></div><div className="action-list">{actions.map(({ title, detail, tone, icon: Icon }) => <button type="button" className={`action-card ${tone}`} key={title}><IconBadge icon={Icon} className="action-icon" /><span className="action-copy"><strong>{title}</strong><small>{detail}</small></span><span className="severity">{tone === 'urgent' ? 'URGENT' : tone === 'due' ? 'DUE' : 'ATTENTION'}</span><ArrowUpRight className="action-arrow" size={16} /></button>)}</div><div className="section-heading task-heading"><div><h2>My due tasks</h2><span>Keep the farm moving</span></div><button className="text-button" type="button">Manage tasks <ArrowUpRight size={14} /></button></div><div className="task-list">{tasks.map((task) => <div className="task-row" key={task.title}><span className={`task-check ${task.status.toLowerCase()}`}><Check size={13} /></span><div><strong>{task.title}</strong><small>{task.assignee} <i /> {task.time}</small></div><span className={`task-status ${task.status.toLowerCase()}`}>{task.status}</span><MoreHorizontal size={17} /></div>)}</div></div><aside className="right-column"><div className="insight-card"><div className="insight-header"><span className="eyebrow">FLOCK INSIGHT</span><span className="spark"><Zap size={14} /></span></div><h3>Water use is 8% lower than the 7-day average</h3><p>Consider checking drinker access and waterline pressure in Shed B before the afternoon round.</p><div className="insight-footer"><span><ShieldCheck size={14} /> Based on 7 days of records</span><button type="button">Dismiss</button></div></div><div className="activity-card"><div className="card-heading"><div><h2>Recent activity</h2><span>Across Green Valley Farms</span></div><button type="button" className="icon-button"><MoreHorizontal size={17} /></button></div><div className="activity-list">{activity.map(({ text, by, time, icon: Icon }) => <div className="activity-row" key={text}><span className="activity-icon"><Icon size={15} /></span><div><strong>{text}</strong><small>{by} <i /> {time}</small></div></div>)}</div><button type="button" className="activity-link">View activity log <ArrowUpRight size={14} /></button></div></aside></div>
          </section>
        )}
      </main>
      <nav className="mobile-nav" aria-label="Mobile navigation">{navItems.map(({ label, icon: Icon }) => <button type="button" key={label} className={active === label ? 'active' : ''} onClick={() => setActive(label)}><Icon size={19} /><span>{label}</span></button>)}</nav>
    </div>
  )
}
