'use client'

import {
  AlertTriangle,
  ArrowRight,
  CalendarDays,
  Check,
  ChevronRight,
  CloudOff,
  Droplets,
  Egg,
  Leaf,
  ListTodo,
  RefreshCw,
  Scale,
  Sparkles,
  Wheat,
  Wifi,
} from 'lucide-react'
import { Button } from '@/components/ui/button'

const tasks = [
  { title: 'Check waterline pressure', assignee: 'Ravi', time: 'Now', tone: 'urgent' },
  { title: 'Record today\'s feed use', assignee: 'You', time: 'By 5:00 pm', tone: 'due' },
  { title: 'Weigh sample birds', assignee: 'Anita', time: 'Tomorrow', tone: 'planned' },
]

export function TodayDashboard({ onRound }: { onRound: () => void }) {
  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-5 px-4 pb-28 pt-5 sm:px-6 lg:pb-8 lg:pt-8">
      <section className="flex flex-col gap-4 rounded-3xl bg-[#173d32] p-5 text-white shadow-[0_18px_50px_-24px_rgba(23,61,50,0.7)] sm:p-7 lg:flex-row lg:items-end lg:justify-between">
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2 text-sm font-medium text-[#b8d7c2]"><Leaf className="size-4" aria-hidden="true" /> Green Valley Farms</div>
          <div><p className="mb-1 text-sm text-[#b8d7c2]">Active batch</p><h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">Batch 24-07</h1></div>
          <div className="flex flex-wrap items-center gap-2 text-sm text-[#d4e7d8]"><span className="rounded-full bg-white/10 px-3 py-1">Shed B</span><span className="rounded-full bg-white/10 px-3 py-1">Day 18</span><span className="flex items-center gap-1.5"><CalendarDays className="size-4" aria-hidden="true" /> 12 October 2026</span></div>
        </div>
        <Button onClick={onRound} className="h-12 justify-between rounded-xl bg-[#d8f36a] px-4 text-[#173d32] hover:bg-[#c8e856] lg:min-w-56" aria-label="Complete daily farm round"><span className="flex items-center gap-2"><Check data-icon="inline-start" /> Complete Daily Round</span><ArrowRight data-icon="inline-end" /></Button>
      </section>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4" aria-label="Farm status">
        <Metric icon={Egg} label="Live birds" value="9,410" note="98.7% of placed" tone="green" />
        <Metric icon={AlertTriangle} label="Today mortality" value="12" note="0.13% of flock" tone="amber" />
        <Metric icon={Wheat} label="Feed runway" value="4.5 days" note="Stock looks healthy" tone="blue" />
        <Metric icon={ListTodo} label="Daily round" value="2 / 4" note="2 items remaining" tone="purple" />
      </section>

      <div className="grid gap-5 lg:grid-cols-[1.15fr_0.85fr]">
        <section className="flex flex-col gap-4 rounded-2xl border border-[#dfe8df] bg-white p-5 shadow-sm sm:p-6">
          <SectionHeading eyebrow="Needs your attention" title="Top actions" action="View all" />
          <div className="flex flex-col gap-3">{[
            { icon: Droplets, title: 'Waterline pressure low in Shed B', detail: 'Check nipple line before the next round', label: 'URGENT', style: 'bg-[#fff0ed] text-[#b93c2d]', iconStyle: 'bg-[#ffe0da] text-[#c44734]' },
            { icon: Wheat, title: "Record today's feed use", detail: 'Daily record is due by 5:00 pm', label: 'DUE', style: 'bg-[#fff7dc] text-[#946d00]', iconStyle: 'bg-[#fff0b6] text-[#9c7200]' },
            { icon: Scale, title: 'Weigh sample birds', detail: 'Scheduled for tomorrow morning', label: 'PLANNED', style: 'bg-[#edf4ef] text-[#477259]', iconStyle: 'bg-[#dfece2] text-[#477259]' },
          ].map((item) => <button key={item.title} onClick={item.title === "Record today's feed use" ? onRound : undefined} className="group flex items-center gap-3 rounded-xl border border-[#e6ece6] p-3 text-left transition hover:border-[#b8cfbd] hover:bg-[#fbfdfb]"><span className={`flex size-10 shrink-0 items-center justify-center rounded-xl ${item.iconStyle}`}><item.icon className="size-5" aria-hidden="true" /></span><span className="min-w-0 flex-1"><span className="flex flex-wrap items-center gap-2"><strong className="text-sm font-semibold text-[#24362b]">{item.title}</strong><span className={`rounded-full px-2 py-0.5 text-[10px] font-bold tracking-wide ${item.style}`}>{item.label}</span></span><span className="mt-1 block text-xs text-[#718076]">{item.detail}</span></span><ChevronRight className="size-4 text-[#a0afa5] transition group-hover:translate-x-0.5" aria-hidden="true" /></button>)}</div>
        </section>

        <section className="flex flex-col gap-4 rounded-2xl border border-[#dfe8df] bg-white p-5 shadow-sm sm:p-6"><SectionHeading eyebrow="Assigned to you" title="My due tasks" action="Open tasks" /><div className="flex flex-col gap-1">{tasks.map((task) => <div key={task.title} className="flex items-center gap-3 border-b border-[#edf1ed] py-3 last:border-0"><span className={`size-2.5 shrink-0 rounded-full ${task.tone === 'urgent' ? 'bg-[#e76750]' : task.tone === 'due' ? 'bg-[#e5b52f]' : 'bg-[#93b79c]'}`} /><span className="min-w-0 flex-1"><strong className="block truncate text-sm font-medium text-[#24362b]">{task.title}</strong><span className="text-xs text-[#7a897e]">{task.assignee}</span></span><span className="text-right text-xs font-medium text-[#66766b]">{task.time}</span></div>)}</div><Button variant="outline" className="mt-auto h-10 w-full rounded-xl border-[#dbe7dc] text-[#31553c]">View all tasks <ArrowRight data-icon="inline-end" /></Button></section>
      </div>

      <section className="flex flex-col gap-4 rounded-2xl border border-[#dfe8df] bg-white p-5 shadow-sm sm:p-6"><SectionHeading eyebrow="Keep working offline" title="Sync status" /><div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-3"><span className="flex size-10 items-center justify-center rounded-full bg-[#fff7dc] text-[#a87c00]"><CloudOff className="size-5" aria-hidden="true" /></span><div><p className="text-sm font-semibold text-[#24362b]">3 records saved locally</p><p className="mt-0.5 text-xs text-[#7a897e]">Pending sync · Last synced 8:42 am</p></div></div><Button variant="outline" className="h-10 rounded-xl border-[#dbe7dc] text-[#31553c]"><RefreshCw data-icon="inline-start" /> Sync now</Button></div></section>

      <section className="grid gap-5 lg:grid-cols-[0.85fr_1.15fr]"><div className="rounded-2xl border border-[#dfe8df] bg-[#f3f8f3] p-5 sm:p-6"><div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.15em] text-[#5e8067]"><Sparkles className="size-4" aria-hidden="true" /> Field note</div><p className="mt-4 text-lg font-medium leading-snug text-[#294732]">"Water access is the first thing to check when birds go off-feed."</p><p className="mt-3 text-xs text-[#6e8172]">From your Shed B operating notes</p></div><div className="rounded-2xl border border-[#dfe8df] bg-white p-5 shadow-sm sm:p-6"><SectionHeading eyebrow="Latest activity" title="Recent records" action="See history" /><div className="mt-2 flex flex-col divide-y divide-[#edf1ed]">{['Daily round started for Shed B','Mortality record saved locally · 12 birds','Feed stock count updated · 1,240 kg'].map((activity, index) => <div key={activity} className="flex items-center gap-3 py-3"><span className="flex size-8 items-center justify-center rounded-lg bg-[#edf4ef] text-[#477259]"><Wifi className="size-4" aria-hidden="true" /></span><p className="flex-1 text-sm text-[#405146]">{activity}</p><span className="text-xs text-[#8a978d]">{index === 0 ? 'Now' : `${index + 1}h ago`}</span></div>)}</div></div></section>
    </div>
  )
}

function Metric({ icon: Icon, label, value, note, tone }: { icon: typeof Egg; label: string; value: string; note: string; tone: string }) { const tones: Record<string, string> = { green: 'bg-[#e9f4ea] text-[#3e7650]', amber: 'bg-[#fff4d5] text-[#a67700]', blue: 'bg-[#e7f2f6] text-[#3c7182]', purple: 'bg-[#eeeaf7] text-[#6d5798]' }; return <div className="flex min-h-32 flex-col justify-between rounded-2xl border border-[#dfe8df] bg-white p-4 shadow-sm"><span className={`flex size-9 items-center justify-center rounded-xl ${tones[tone]}`}><Icon className="size-4" aria-hidden="true" /></span><div><p className="text-xl font-semibold tracking-tight text-[#24362b] sm:text-2xl">{value}</p><p className="text-xs font-medium text-[#59685d]">{label}</p><p className="mt-1 text-[11px] text-[#8a978d]">{note}</p></div></div> }
function SectionHeading({ eyebrow, title, action }: { eyebrow: string; title: string; action?: string }) { return <div className="flex items-end justify-between gap-3"><div><p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#77927c]">{eyebrow}</p><h2 className="mt-1 text-lg font-semibold tracking-tight text-[#24362b]">{title}</h2></div>{action && <button className="text-xs font-semibold text-[#4c8058] hover:underline">{action}</button>}</div> }

export function BottomNav({ active, onNavigate }: { active: string; onNavigate: (value: string) => void }) { const items = [{ id: 'today', label: 'Today', icon: Leaf }, { id: 'record', label: 'Record', icon: Check }, { id: 'batches', label: 'Batches', icon: Egg }, { id: 'tasks', label: 'Tasks', icon: ListTodo }, { id: 'more', label: 'More', icon: Sparkles }]; return <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-[#dfe8df] bg-white/95 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur lg:hidden" aria-label="Primary navigation"><div className="mx-auto flex max-w-md items-center justify-around">{items.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => onNavigate(id)} className={`flex min-w-14 flex-col items-center gap-1 rounded-xl px-3 py-1.5 text-[10px] font-semibold transition ${active === id ? 'bg-[#e9f4ea] text-[#315f3d]' : 'text-[#849188] hover:text-[#315f3d]'}`} aria-current={active === id ? 'page' : undefined}><Icon className="size-5" aria-hidden="true" /><span>{label}</span></button>)}</div></nav> }

export function DesktopNav({ active, onNavigate }: { active: string; onNavigate: (value: string) => void }) { const items = [{ id: 'today', label: 'Today', icon: Leaf }, { id: 'record', label: 'Daily round', icon: Check }, { id: 'batches', label: 'Batches', icon: Egg }, { id: 'tasks', label: 'Tasks', icon: ListTodo }, { id: 'more', label: 'More', icon: Sparkles }]; return <aside className="hidden w-60 shrink-0 border-r border-[#dfe8df] bg-[#f8fbf8] p-4 lg:flex lg:flex-col"><div className="flex items-center gap-2 px-3 py-4"><span className="flex size-9 items-center justify-center rounded-xl bg-[#d8f36a] text-[#173d32]"><Leaf className="size-5" /></span><span className="text-sm font-bold tracking-tight text-[#244c31]">Poultry <span className="text-[#719442]">Intelligence</span></span></div><div className="mt-6 flex flex-col gap-1">{items.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => onNavigate(id)} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium transition ${active === id ? 'bg-[#e2f0e4] text-[#315f3d]' : 'text-[#718076] hover:bg-white hover:text-[#315f3d]'}`}><Icon className="size-4" aria-hidden="true" />{label}</button>)}</div><div className="mt-auto rounded-2xl bg-[#173d32] p-4 text-white"><p className="text-xs font-semibold text-[#c9dfcb]">Offline mode</p><p className="mt-1 text-xs leading-relaxed text-[#a9c7b0]">3 records are waiting to sync.</p><button className="mt-3 text-xs font-semibold text-[#d8f36a]">Review records →</button></div></aside> }

export function Header({ onRoleChange }: { onRoleChange: () => void }) { return <header className="flex items-center justify-between border-b border-[#dfe8df] bg-white px-4 py-3 sm:px-6"><div className="flex items-center gap-2 lg:hidden"><span className="flex size-8 items-center justify-center rounded-lg bg-[#d8f36a] text-[#173d32]"><Leaf className="size-4" /></span><span className="text-sm font-bold text-[#244c31]">Poultry Intelligence</span></div><div className="hidden text-sm font-medium text-[#6d7d71] lg:block">Green Valley Farms <span className="mx-2 text-[#bdc9be]">/</span> {onRoleChange ? 'Operations overview' : 'Operations'}</div><div className="flex items-center gap-3"><button onClick={onRoleChange} className="rounded-full border border-[#dce8de] px-3 py-1.5 text-xs font-semibold text-[#486350] hover:bg-[#f3f8f3]">Owner view</button><span className="flex size-8 items-center justify-center rounded-full bg-[#dbeee0] text-xs font-bold text-[#477259]">AM</span></div></header> }

export function EmptyPlaceholder({ title }: { title: string }) { return <div className="mx-auto flex min-h-[50vh] max-w-xl flex-col items-center justify-center gap-3 px-6 text-center"><div className="flex size-16 items-center justify-center rounded-2xl bg-[#e9f4ea] text-[#477259]"><Sparkles className="size-7" /></div><h1 className="text-2xl font-semibold text-[#24362b]">{title}</h1><p className="text-sm text-[#718076]">This local-first workspace is ready for the next farm module.</p></div> }
